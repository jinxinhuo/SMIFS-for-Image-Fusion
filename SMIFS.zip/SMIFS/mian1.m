% If you use this MATLAB code please reference the following paper. 
% Qian Jiang, Xin Jin, Xiaohui Cui, Shaowen Yao, Keqin Li, Wei Zhou, 
% A Lightweight Multimode Medical Image Fusion Method Using Similarity 
% Measure between Intuitionistic Fuzzy Sets Joint Laplacian Pyramid, 
% IEEE Transactions on Emerging Topics in Computational Intelligence, 
% 2022, accepted
% https://www.researchgate.net/profile/Qian-Jiang-29

clc;
clear all;
close all;
home
addpath(genpath(pwd));
 
im1=imread('015 (1).png');
im2=imread('015.png');
im1 = double(im1);
im2 = double(im2);

zt=3;ap=1;mp=3;
FF= fuse_SMIFS(double(im1), double(im2), zt, ap, mp);  
FF=uint8(FF);imwrite(FF,'main.tif');FF=imread('main.tif');

[Qabf1,LABF,NABF,NABF1]= Qabff(im1, im2, FF);
MI=mutural_information(im1,im2,FF,256);
std= std22(FF);
nfmi = fmi(im1, im2, FF);
 
figure,imshow(im1,[]);
figure,imshow(im2,[]);
figure,imshow(FF,[]);
index(1,1)=Qabf1;
index(1,2)=MI;
index(1,3)=std;
index(1,4)=nfmi;
index





