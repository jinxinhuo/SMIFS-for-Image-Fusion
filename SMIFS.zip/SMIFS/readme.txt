This image fusion code is downloaded from  GitHub at: , 

This  code is associated with the following paper:
Qian Jiang, Xin Jin, Xiaohui Cui, Shaowen Yao, Keqin Li, Wei Zhou, A Lightweight Multimode Medical Image Fusion Method Using Similarity Measure between Intuitionistic Fuzzy Sets Joint Laplacian Pyramid, IEEE Transactions on Emerging Topics in Computational Intelligence, 2022, accepted. doi: 

Please refer to the above publication if you use this code.


This code is only used for research purposes.

